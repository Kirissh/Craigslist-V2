import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// Get the directory name properly in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from .env file
dotenv.config({ path: path.resolve(process.cwd(), '.env') });

interface Config {
  supabase: {
    url: string;
    anonKey: string;
    serviceKey: string;
  };
  gemini: {
    apiKey: string;
  };
  server: {
    port: number;
    clientUrl: string;
    nodeEnv: string;
  };
}

const config: Config = {
  supabase: {
    url: process.env.SUPABASE_URL || 'https://mgwnecbvbgsvdjsrjklb.supabase.co',
    anonKey: process.env.SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1nd25lY2J2YmdzdmRqc3Jqa2xiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDYyODM3NjgsImV4cCI6MjA2MTg1OTc2OH0.pTcq9skP_X5gmD1StZ9DbV0FjkDdA8lrkrZ1yQ20hyo',
    serviceKey: process.env.SUPABASE_SERVICE_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1nd25lY2J2YmdzdmRqc3Jqa2xiIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0NjI4Mzc2OCwiZXhwIjoyMDYxODU5NzY4fQ.bVVkjnKCooOSWj5wVN1jrY4xnP-lUa64xwLHrHLLDFQ',
  },
  gemini: {
    apiKey: process.env.GEMINI_API_KEY || 'AIzaSyBe8B2Stu78UUpY6DXXQvvtUw2fleFZar8',
  },
  server: {
    port: parseInt(process.env.PORT || '3001', 10),
    clientUrl: process.env.CLIENT_URL || 'http://localhost:5173',
    nodeEnv: process.env.NODE_ENV || 'development',
  },
};

export default config; 